<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nos produits</title>
</head>
<body>
    <h1>Nos produits</h1>

    <a href="page2.php?article=jean&couleur=bleu&prix=30">Jean bleu</a>
    <br>
    <a href="page2.php?article=robe&couleur=rouge&prix=40">Robe rouge</a>
    <br>
    <a href="page2.php?article=pull&couleur=blanc&prix=30">Pull blanc</a>
</body>
</html>