
            </div><!-- .col-12 -->
          </div><!-- .row -->  
    </div> <!-- .container -->


    <!-- footer -->
    <div class="container">
          <hr>
          <footer>
            <div class="row text-center">
              <div class="col">
                <p>Copyright &copy; Ma Boutique - 2018</p>
              </div>
            </div>
          </footer>
    </div><!-- .container -->
</body>
</html>
