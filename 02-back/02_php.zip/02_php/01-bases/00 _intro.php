<?php 
/*
PHP => Hypertext Preprocesseur : 
    *   Langage de programmation de script 
    **  Open show_source
    *** Spécifique au dévéloppement de sites web
 
 5 langages interviennent dans la création d'un site :
    CONCEPTION (front end)
    *   HTML 
    **  CSS 
    *** JS

    FONCTIONNELS (back end)
     *  PHP => récupération  et traitement des données
     ** SQL => interroge la BDD 



Le site dynamique est constitué d'une partie front (HTML...) accessible à l'internaute et d'une partie back (PHP...) seulement accessible par l'administrateur du site.
*/



 